import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
app.use(express.json({ limit: '50mb' }));

const PORT = 3000;

// Initialize Gemini Client
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

const coachSchema = {
  type: Type.OBJECT,
  properties: {
    status: { type: Type.STRING, description: "One of: 'ON_TRACK', 'NEEDS_ATTENTION', 'OVER_TARGET'" },
    score: { type: Type.NUMBER, description: "Daily adherence score 0-100" },
    missingNutrients: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Nutrients (macros, vitamins, pre/probiotics) lacking today" },
    suggestedMeals: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Specific food/meal suggestions to hit remaining targets, respecting user health conditions (e.g., adding/removing specific items)" },
    actionPlan: { type: Type.STRING, description: "A conversational, encouraging coach message explaining what to eat/avoid." }
  },
  required: ["status", "score", "missingNutrients", "suggestedMeals", "actionPlan"]
};

app.post('/api/coach', async (req, res) => {
  try {
    const { profile, todayTotals, meals } = req.body;
    const prompt = `You are an AI Nutrition Coach. The user has this profile: ${JSON.stringify(profile)}.
    They have consumed today: ${JSON.stringify(todayTotals)}. 
    Their meals today were: ${JSON.stringify(meals)}.
    
    Calculate their gaps against their target macros. Also check for general lack of pre/probiotics or vitamins based on what they ate. Keep their health conditions in mind. 
    Provide specific food items they should eat right now to reach their goals, and things they should avoid if they are over target.`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: coachSchema,
      }
    });

    res.json(JSON.parse(response.text?.trim() || '{}'));
  } catch (error: any) {
    console.error("Coach AI Error:", error);
    res.status(500).json({ error: "Failed to generate coaching insights" });
  }
});

app.post('/api/chat', async (req, res) => {
  try {
    const { message, history, profile, todayTotals, meals } = req.body;
    
    let historyText = history.map((m: any) => `${m.role === 'user' ? 'User' : 'Coach'}: ${m.content}`).join('\n');

    const prompt = `You are "Full Meal AI", an advanced, friendly, and scientifically reasonable AI Nutritionist.
    
    User Profile:
    ${JSON.stringify(profile)}

    Today's Intake:
    ${JSON.stringify(todayTotals)}
    Meals Logged Today: ${meals.join(', ') || 'None'}

    Conversation History:
    ${historyText}

    User: ${message}
    Coach:`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    res.json({ reply: response.text?.trim() || "Sorry, I couldn't process that." });
  } catch (error: any) {
    console.error("Chat AI Error:", error);
    res.status(500).json({ error: "Failed to generate chat reply" });
  }
});

// Defining the response schema for Gemini
const foodAnalysisSchema = {
  type: Type.OBJECT,
  properties: {
    isFood: {
      type: Type.BOOLEAN,
      description: "Must be true ONLY if the image clearly contains food. If it is blurry, unclear, partially visible, a person, an object, or non-food, set to false.",
    },
    rejectionReason: {
      type: Type.STRING,
      description: "If isFood is false, specify a polite reason: e.g., 'Unable to analyze the food properly. Please upload a clearer and fully visible food image.' Leave empty if true."
    },
    items: {
      type: Type.ARRAY,
      description: "List of identified food items in the image. Support multi-food recognition including Indian foods.",
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          portion: { type: Type.STRING, description: "Approximate portion size (e.g., '1 cup', '200g', '1 medium piece')" },
          calories: { type: Type.NUMBER },
          protein: { type: Type.NUMBER, description: "Protein in grams" },
          carbs: { type: Type.NUMBER, description: "Carbohydrates in grams" },
          fats: { type: Type.NUMBER, description: "Fats in grams" },
          fiber: { type: Type.NUMBER, description: "Dietary fiber in grams" },
          vitamins: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Key vitamins present (e.g., 'Vitamin C', 'Vitamin A')" },
          minerals: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Key minerals present (e.g., 'Iron', 'Calcium')" },
          hydrationValue: { type: Type.STRING, description: "Hydration level of the food, e.g., 'High', 'Medium', 'Low'" },
          gutHealthScore: { type: Type.NUMBER, description: "Score from 1 to 10 on how beneficial this food is for gut microbiome health" },
        },
        required: ["name", "portion", "calories", "protein", "carbs", "fats", "fiber", "vitamins", "minerals", "hydrationValue", "gutHealthScore"]
      }
    },
    totals: {
      type: Type.OBJECT,
      properties: {
        calories: { type: Type.NUMBER },
        protein: { type: Type.NUMBER },
        carbs: { type: Type.NUMBER },
        fats: { type: Type.NUMBER },
        fiber: { type: Type.NUMBER },
      },
      required: ["calories", "protein", "carbs", "fats", "fiber"]
    },
    healthInsights: {
      type: Type.OBJECT,
      properties: {
        proteinDeficiency: { type: Type.BOOLEAN, description: "True if the meal is significantly lacking in protein compared to typical requirements" },
        excessRefinedCarbs: { type: Type.BOOLEAN, description: "True if the meal contains high amounts of refined carbohydrates" },
        fiberInsufficiency: { type: Type.BOOLEAN, description: "True if the meal has very low dietary fiber" },
        poorHydration: { type: Type.BOOLEAN, description: "True if the meal largely consists of dry, low-water foods" },
        nutritionalImbalance: { type: Type.BOOLEAN, description: "True if the macro split is highly skewed (e.g., 90% fats)" },
        mealQualityScore: { type: Type.NUMBER, description: "Overall meal quality score out of 100 based on nutritional density and balance" },
        metabolicHealthIndicators: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Short notes on how this meal affects metabolic health (e.g., 'High glycemic load may spike blood sugar')" },
        recommendations: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Actionable recommendations to improve this meal or balance the rest of the day" },
      },
      required: ["proteinDeficiency", "excessRefinedCarbs", "fiberInsufficiency", "poorHydration", "nutritionalImbalance", "mealQualityScore", "metabolicHealthIndicators", "recommendations"]
    }
  },
  required: ["isFood", "items", "totals", "healthInsights"]
};

app.post('/api/analyze-food', async (req, res) => {
  try {
    const { imageBase64 } = req.body;
    
    if (!imageBase64) {
      return res.status(400).json({ error: 'No image provided' });
    }

    // Strip out the data URL prefix if present
    const base64Data = imageBase64.replace(/^data:image\/\w+;base64,/, '');

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: [
        {
          inlineData: {
            mimeType: 'image/jpeg',
            data: base64Data
          }
        },
        'Analyze this image for food. Identify all distinct food items perfectly. Even complex or mixed dishes (like Indian cuisines, thalis, curries) should be identified. Calculate the estimated macros realistically, portion sizes, and provide deep health insights focusing on metabolic health. If the image is blurry, unclear, partially visible, or non-food, set isFood to false and provide a polite rejectionReason (e.g., "Unable to analyze the food properly. Please upload a clearer and fully visible food image.").'
      ],
      config: {
        responseMimeType: 'application/json',
        responseSchema: foodAnalysisSchema,
      }
    });

    const resultText = response.text.trim();
    const resultObj = JSON.parse(resultText);

    res.json(resultObj);
  } catch (error: any) {
    console.error("Error analyzing food:", error);
    res.status(500).json({ error: error.message || "Failed to analyze food" });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
